import React from 'react'

const FacebookChat = () => {
    return (
        <div>
            <h1>Hi</h1>
        </div>
    )
}

export default FacebookChat

